# Cookie Clicker Downloadable HTML
<br><br>
Cookie Clicker source code for educational purposes. <br>
Download and extract from the "Releases" section.<br>
Or use the <a target="_blank" href="https://sushi8756.github.io/Cookie-Clicker-Source-Code/">website</a>!<br><br>
Website version loads a bit faster, but can get blocked.<br>
Downloadable HTML version loads a bit slower, but cannot get blocked.<br><br>
I might update this to later versions when they come out, but don't count on it. (It took me 2 years from 2.048 to 2.052 whoops)<br>
Credits go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
<br><br>
